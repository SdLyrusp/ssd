#include "tasks/task_manager.h"
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/sched/task.h>
#include <linux/sched/signal.h>
#include <linux/err.h>

/*
 * 线程是否仍存活？(适用于 4.x~6.x 内核)
 */
bool thread_is_alive(struct task_struct *p)
{
    if (!p)
        return false;

    /* EXIT_ZOMBIE = 2, EXIT_DEAD = 4 */
    unsigned int state = READ_ONCE(p->exit_state);

    return !(state & (EXIT_ZOMBIE | EXIT_DEAD));
}

/*
 * 创建多个线程
 */
int run_tasks(struct k_task *tasks, size_t count)
{
    size_t i;

    for (i = 0; i < count; i++) {
        char task_nickname[20];

        scnprintf(task_nickname, sizeof(task_nickname), "task_%zu", i);

        /* 使用 kthread_create + wake_up_process 防止竞态 */
        struct task_struct *task = kthread_create(tasks[i].task_func_ptr,
                                                  NULL,
                                                  "%s", task_nickname);

        if (IS_ERR(task))
            return PTR_ERR(task);

        /* 启动线程 */
        wake_up_process(task);

        tasks[i].task_thread = task;
    }

    return 0;
}

/*
 * 停止多个线程
 */
void stop_tasks(struct k_task *tasks, size_t count)
{
    size_t i;

    for (i = 0; i < count; i++) {
        struct task_struct *t = tasks[i].task_thread;

        if (t && !IS_ERR(t)) {

            /* 避免再次 stop 已退出线程 */
            if (thread_is_alive(t)) {
                kthread_stop(t);   // 安全阻塞直到线程退出
            }

            tasks[i].task_thread = NULL;
        }
    }
}
