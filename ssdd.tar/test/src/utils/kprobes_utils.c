#include <linux/kprobes.h>
#include "utils/kprobes_utils.h"

kallsyms_lookup_name_t _kallsyms_lookup(void) {
    struct kprobe kp = { .symbol_name = "kallsyms_lookup_name" };
    int ret;
    kallsyms_lookup_name_t addr = NULL;

    ret = register_kprobe(&kp);
    addr = (kallsyms_lookup_name_t)kp.addr;
    unregister_kprobe(&kp);

    return addr;
}
