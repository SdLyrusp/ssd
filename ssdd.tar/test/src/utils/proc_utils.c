#include <linux/sched/task.h>
#include <linux/mm.h>
#include <linux/uaccess.h>
#include <linux/rcupdate.h>
#include "utils/proc_utils.h"

char *read_cmdline_from_task(pid_t pid, size_t *out_size)
{
    struct task_struct *task;
    struct mm_struct *mm;
    char *buffer;
    size_t size;
    ssize_t nread;

    /* 获取 task */
    rcu_read_lock();
    task = pid_task(find_vpid(pid), PIDTYPE_PID);
    if (!task) {
        rcu_read_unlock();
        return NULL;
    }

    mm = get_task_mm(task);
    rcu_read_unlock();
    if (!mm)
        return NULL;

    /* 在 mmap_lock 期间读取 arg_start/arg_end */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,8,0)
    mmap_read_lock(mm);
#else
    down_read(&mm->mmap_sem);
#endif

    size = mm->arg_end - mm->arg_start;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,8,0)
    mmap_read_unlock(mm);
#else
    up_read(&mm->mmap_sem);
#endif

    if (size == 0) {
        mmput(mm);
        return NULL;
    }

    buffer = kmalloc(size + 1, GFP_KERNEL);
    if (!buffer) {
        mmput(mm);
        return NULL;
    }

    /* 从目标进程读取 argv */
    nread = access_process_vm(task, mm->arg_start, buffer, size, 0);

    mmput(mm);

    if (nread <= 0) {
        kfree(buffer);
        return NULL;
    }

    /* 修正不足读取情况 */
    if (nread < size)
        size = nread;

    buffer[size] = '\0';

    if (out_size)
        *out_size = size;

    return buffer;
}
