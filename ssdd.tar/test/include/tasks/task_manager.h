#ifndef TASK_MANAGER_H
#define TASK_MANAGER_H

#include <linux/types.h>   /* size_t */
#include <linux/kthread.h> /* kthread helpers (for type clarity) */
#include <linux/err.h>     /* IS_ERR / PTR_ERR */

/* thread function signature used by kthread_run/kthread_create */
typedef int (*kthread_fn_t)(void *data);

/* Forward declaration to avoid heavy includes in consumers */
struct task_struct;

/* Structure representing a kernel-managed task */
struct k_task {
    kthread_fn_t task_func_ptr;   /* thread entry function (must check kthread_should_stop()) */
    void *task_data;              /* optional data pointer passed to thread_fn */
    struct task_struct *task_thread; /* pointer to created thread, NULL if not created */
};

/* API */
extern bool thread_is_alive(struct task_struct *p);
extern int run_tasks(struct k_task *tasks, size_t count);
extern void stop_tasks(struct k_task *tasks, size_t count);

#endif /* TASK_MANAGER_H */
